﻿var option = Math.round(Math.random() * 10);
xmlDoc = loadXMLDoc("books.xml");

document.writeln(xmlDoc.getElementsByTagName("name")[option].childNodes[0].nodeValue);
document.writeln("<br/>");
document.writeln(xmlDoc.getElementsByTagName("published")[option].childNodes[0].nodeValue);
document.writeln("<br/>");
document.writeln(xmlDoc.getElementsByTagName("author")[option].childNodes[0].nodeValue);


function loadXMLDoc(dname) {
    try //Internet Explorer
    {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
    }
    catch (e) {
        try //Firefox, Mozilla, Opera, etc.
        {
            xmlDoc = document.implementation.createDocument("", "", null);
        }
        catch (e) { alert(e.message) }
    }
    try {
        xmlDoc.async = false;
        xmlDoc.load(dname);
        return (xmlDoc);
    }
    catch (e) { alert(e.message) }
    return (null);
}

function random() {
    option = Math.round(Math.random() * 10);
    update();
}

function update() {

    document.write(xmlDoc.getElementsByTagName("name")[option].childNodes[0].nodeValue);
    document.write("<br/>");
    document.write(xmlDoc.getElementsByTagName("published")[option].childNodes[0].nodeValue);
    document.write("<br/>");
    document.write(xmlDoc.getElementsByTagName("author")[option].childNodes[0].nodeValue);
    create();
}

function create() {
    var btn = document.createElement("BUTTON");   // Create a <button> element
    btn.innerHTML = "Random";                   // Insert text
    document.body.appendChild(btn);               // Append <button> to <body>
    btn.addEventListener("click", goBack(), false);
}

function goBack() {
    history.go(-1);
}
